<script>
	import Documents from '$lib/components/workspace/Documents.svelte';
</script>

<Documents />
