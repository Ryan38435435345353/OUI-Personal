<script>
	import Functions from '$lib/components/workspace/Functions.svelte';
</script>

<Functions />
