<script>
	import Settings from '$lib/components/admin/Settings.svelte';
</script>

<Settings />
